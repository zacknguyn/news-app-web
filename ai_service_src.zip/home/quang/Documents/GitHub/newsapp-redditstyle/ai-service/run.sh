#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${PYTHON_BIN:-$SCRIPT_DIR/.venv/bin/python}"

"$PYTHON_BIN" -m uvicorn app.main:app --host "${AI_SERVICE_HOST:-0.0.0.0}" --port "${AI_SERVICE_PORT:-8000}"
