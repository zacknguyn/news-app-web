# Tourane News AI Service

Local FastAPI service for the Spring Boot backend.

It exposes the same endpoints used by the Colab notebooks:

- `GET /health`
- `POST /recommend-reddit`
- `POST /summarize`

## Setup

Use Python 3.11+.

Your machine has an NVIDIA GPU, so use the CUDA 12.1 PyTorch wheel. This works with NVIDIA drivers that report CUDA 12.2+.

```bash
cd ai-service
python -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install --no-cache-dir -r requirements-cu121.txt
```

If you must run CPU-only:

```bash
pip install --no-cache-dir -r requirements-cpu.txt
```

## Run

```bash
./run.sh
```

Then run the Spring Boot backend from the repo root:

```bash
AI_ENABLED=true AI_BASE_URL=http://localhost:8000 ./mvnw spring-boot:run
```

## Disk Notes

PyTorch GPU wheels are large. If install fails with `No space left on device`, clean pip cache and recreate the virtualenv:

```bash
rm -rf ~/.cache/pip
rm -rf ai-service/.venv
```

Then run setup again.

## Model Notes

The service lazy-loads models on first request.

Defaults:

- summarization: `Qwen/Qwen3-4B`
- recommendation: `google/gemma-3-4b-it`

Gemma is gated on Hugging Face. If you use it, set:

```bash
export HF_TOKEN=your_huggingface_token
```

You can override models:

```bash
export SUMMARIZATION_MODEL_ID=Qwen/Qwen3-4B
export RECOMMENDATION_MODEL_ID=google/gemma-3-4b-it
```

For a 6GB GPU, keep `AI_USE_4BIT=true`.
