import gc
import re

import torch

from app.config import settings
from app.model_loader import get_summarization_model


def _clean_model_output(text: str) -> str:
    return re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL).strip()


def summarize_article(
    article_text: str,
    max_bullets: int = 6,
    language: str = "vi",
    max_new_tokens: int = 512,
    temperature: float = 0.2,
    top_p: float = 0.8,
) -> str:
    if not article_text or not article_text.strip():
        raise ValueError("text is required")

    tokenizer, model = get_summarization_model()
    max_bullets = max(1, min(int(max_bullets), 12))
    language_name = "Vietnamese" if language.lower().startswith("vi") else "English"

    system_prompt = (
        "You are an article summarization API. "
        "Return only the key points. Do not add facts that are not in the input. "
        "Do not include introductions, conclusions, markdown tables, or citations."
    )
    user_prompt = f"""
Summarize the following article into at most {max_bullets} concise key points in {language_name}.

Output format:
- one key point per bullet
- each bullet should be short and clear
- preserve important names, numbers, dates, causes, effects, and decisions

Article:
{article_text.strip()}
""".strip()

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]
    prompt = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=False,
    )
    inputs = tokenizer(
        [prompt],
        return_tensors="pt",
        truncation=True,
        max_length=settings.max_input_tokens,
    ).to(model.device)

    with torch.inference_mode():
        generated_ids = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=temperature > 0,
            temperature=max(0.01, float(temperature)),
            top_p=float(top_p),
            top_k=20,
            repetition_penalty=1.08,
            pad_token_id=tokenizer.eos_token_id,
        )

    output_ids = generated_ids[0][inputs.input_ids.shape[-1] :]
    output = tokenizer.decode(output_ids, skip_special_tokens=True)

    del inputs, generated_ids, output_ids
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    gc.collect()

    return _clean_model_output(output)
