from pydantic import BaseModel, Field


class SummarizeRequest(BaseModel):
    text: str = Field(..., description="Raw article text")
    max_bullets: int = Field(6, ge=1, le=12)
    max_points: int | None = Field(None, ge=1, le=12)
    language: str = "vi"
    max_new_tokens: int = Field(512, ge=64, le=2048)
    temperature: float = Field(0.2, ge=0.0, le=1.5)
    top_p: float = Field(0.8, ge=0.1, le=1.0)


class SummarizeResponse(BaseModel):
    summary: str
    model: str
    input_chars: int


class RedditStyleArticle(BaseModel):
    id: str
    title: str
    topics: list[str] = Field(default_factory=list)
    author: str
    author_score: int


class UserPreference(BaseModel):
    top_upvoted_topics: list[str] = Field(default_factory=list)
    favorite_authors: list[str] = Field(default_factory=list)


class RedditRecRequest(BaseModel):
    user_preference: UserPreference
    candidate_articles: list[RedditStyleArticle]
    num_recommendations: int = Field(3, ge=1, le=10)


class RedditRecResponse(BaseModel):
    recommended_ids: list[str]
