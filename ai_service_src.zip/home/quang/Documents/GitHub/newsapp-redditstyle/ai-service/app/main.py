from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.recommendation import generate_recommendations
from app.schemas import (
    RedditRecRequest,
    RedditRecResponse,
    SummarizeRequest,
    SummarizeResponse,
)
from app.summarization import summarize_article

app = FastAPI(title="Tourane News AI Service", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health():
    return {
        "status": "ok",
        "summarization_model": settings.summarization_model_id,
        "recommendation_model": settings.recommendation_model_id,
    }


@app.post("/summarize", response_model=SummarizeResponse)
def summarize_endpoint(payload: SummarizeRequest):
    try:
        bullet_count = payload.max_points if payload.max_points is not None else payload.max_bullets
        summary = summarize_article(
            article_text=payload.text,
            max_bullets=bullet_count,
            language=payload.language,
            max_new_tokens=payload.max_new_tokens,
            temperature=payload.temperature,
            top_p=payload.top_p,
        )
        return SummarizeResponse(
            summary=summary,
            model=settings.summarization_model_id,
            input_chars=len(payload.text),
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.post("/recommend-reddit", response_model=RedditRecResponse)
def recommend_reddit(payload: RedditRecRequest):
    try:
        return RedditRecResponse(recommended_ids=generate_recommendations(payload))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
