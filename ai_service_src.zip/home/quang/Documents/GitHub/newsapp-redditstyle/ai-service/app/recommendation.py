import json
import re

import torch

from app.model_loader import get_recommendation_model
from app.schemas import RedditRecRequest


def _extract_recommended_ids(model_output: str) -> list[str]:
    match = re.search(r'\{"recommended_ids"\s*:\s*\[[^\]]*]}', model_output)
    if match:
        try:
            data = json.loads(match.group(0))
            return [str(item) for item in data.get("recommended_ids", [])]
        except json.JSONDecodeError:
            return []

    start = model_output.find("{")
    end = model_output.rfind("}")
    if start >= 0 and end > start:
        try:
            data = json.loads(model_output[start : end + 1])
            return [str(item) for item in data.get("recommended_ids", [])]
        except json.JSONDecodeError:
            return []
    return []


def generate_recommendations(request: RedditRecRequest) -> list[str]:
    tokenizer, model = get_recommendation_model()
    user_pref = request.user_preference
    num_recommendations = request.num_recommendations

    upvoted_topics = ", ".join(user_pref.top_upvoted_topics) if user_pref.top_upvoted_topics else "none"
    favorite_authors = ", ".join(user_pref.favorite_authors) if user_pref.favorite_authors else "none"
    candidate_articles = "\n".join(
        (
            f"- ID: {article.id}, Title: {article.title}, Topics: {', '.join(article.topics)}, "
            f"Author: {article.author}, Author Score: {article.author_score}"
        )
        for article in request.candidate_articles
    )

    prompt = f"""Bạn là một thuật toán tối ưu Home Feed cho mạng xã hội đọc báo. Bạn phải hành xử như một chuyên gia. Bạn phải trả lời bằng tiếng Việt.
Nhiệm vụ của bạn là đề xuất {num_recommendations} bài viết từ danh sách các bài viết ứng cử viên cho người dùng, dựa trên sở thích cá nhân và bộ lọc cộng đồng. Bạn phải TUYỆT ĐỐI tuân thủ các tiêu chí chấm điểm và định dạng phản hồi.

Danh sách bài viết ứng cử viên; chỉ được chọn ID có trong danh sách này:
{candidate_articles}

Tiêu chí đánh giá và suy luận:
1. ƯU TIÊN CAO: Những bài viết thuộc các chủ đề ({upvoted_topics}) hoặc của các tác giả ({favorite_authors}) mà người dùng đã upvote nhiều nhất.
2. HẠN CHẾ/LOẠI BỎ: Những bài viết có `Author Score` thấp hoặc âm. Không đề xuất author score âm trừ khi cực kỳ phù hợp.
3. Định dạng phản hồi: TRẢ VỀ DUY NHẤT JSON: {{"recommended_ids": ["id1", "id2"]}}
"""

    input_ids = tokenizer(prompt, return_tensors="pt").to(model.device)
    with torch.inference_mode():
        output = model.generate(
            **input_ids,
            max_new_tokens=200,
            do_sample=False,
            temperature=0.1,
            top_k=50,
            top_p=0.95,
            num_return_sequences=1,
            pad_token_id=tokenizer.eos_token_id,
        )

    decoded_output = tokenizer.decode(output[0], skip_special_tokens=True)
    return _extract_recommended_ids(decoded_output)[:num_recommendations]
