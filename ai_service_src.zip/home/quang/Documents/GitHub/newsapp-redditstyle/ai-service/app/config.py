import os


class Settings:
    summarization_model_id = os.getenv("SUMMARIZATION_MODEL_ID", "Qwen/Qwen3-4B")
    recommendation_model_id = os.getenv("RECOMMENDATION_MODEL_ID", "google/gemma-3-4b-it")
    hf_token = os.getenv("HF_TOKEN") or None
    use_4bit = os.getenv("AI_USE_4BIT", "true").lower() in {"1", "true", "yes", "on"}
    max_input_tokens = int(os.getenv("AI_MAX_INPUT_TOKENS", "28672"))


settings = Settings()
