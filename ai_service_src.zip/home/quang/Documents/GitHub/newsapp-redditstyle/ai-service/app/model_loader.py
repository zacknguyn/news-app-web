from functools import lru_cache

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

from app.config import settings


def _quantization_config():
    if not settings.use_4bit:
        return None
    return BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32,
        bnb_4bit_use_double_quant=True,
    )


def _model_kwargs():
    kwargs = {
        "device_map": "auto",
        "trust_remote_code": True,
        "token": settings.hf_token,
    }
    quant_config = _quantization_config()
    if quant_config is not None:
        kwargs["quantization_config"] = quant_config
    else:
        kwargs["torch_dtype"] = "auto"
    return kwargs


@lru_cache(maxsize=1)
def get_summarization_model():
    tokenizer = AutoTokenizer.from_pretrained(
        settings.summarization_model_id,
        trust_remote_code=True,
        token=settings.hf_token,
    )
    model = AutoModelForCausalLM.from_pretrained(settings.summarization_model_id, **_model_kwargs())
    model.eval()
    return tokenizer, model


@lru_cache(maxsize=1)
def get_recommendation_model():
    tokenizer = AutoTokenizer.from_pretrained(
        settings.recommendation_model_id,
        trust_remote_code=True,
        token=settings.hf_token,
    )
    model = AutoModelForCausalLM.from_pretrained(settings.recommendation_model_id, **_model_kwargs())
    model.eval()
    return tokenizer, model
